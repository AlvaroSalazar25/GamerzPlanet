package net.eegg.ProyectoGamerzPlanet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoGamerzPlanetApplicationTests {

	@Test
	void contextLoads() {
	}

}
